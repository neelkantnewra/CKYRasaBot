import time
from flask import Flask , jsonify,request

app = Flask(__name__)

# @app.route("/")
# def hello():
#     return "hello, bots"


sender_store = {"123":{"paused":True, "replies":[]}}


@app.route('/',methods=["GET","POST"])
def chat(sender_id):
    if request.method == "POST":
        if sender_id in sender_store:
            sender_store[sender_id]["replies"].append(request.get_json()["message"])
            return jsonify(sender_store[sender_id])
        else:
            return jsonify({"error":"sender_id not found"})

    else:
        if sender_id not in sender_store:
            sender_store[sender_id] = {"paused":True, "replies":[]}

        while len(sender_store[sender_id]["replies"]) == 0:
            time.sleep(1)

        message = sender_store[sender_id]["replies"].pop(0)
        return jsonify({"message":message})

if __name__ == "__main__":
    app.run(host=app.config.get("http://127.0.0.1:3000/"))
